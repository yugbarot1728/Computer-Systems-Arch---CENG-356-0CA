#ifndef MIPS_ASM_H
#define MIPS_ASM_H

#include "header.h"
#include <string.h>
#include <ctype.h>

/* global label counter */
extern int n_Label;

/* register name table */
extern char *regNameTab[N_REG];

/* function prototypes */
char *strlwr(char *s);
int findLabel(char *label);
int getRegNum(char *regName);
int addLabel(char *label, int segType, int offset);

#endif
