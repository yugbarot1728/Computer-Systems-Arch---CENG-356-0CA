/*
 ============================================================================
 Name        : lab8_9.c
 Author      : Austin Tian
 Revised by  : Yug Barot
 Version     :
 Copyright   : Copyright 2023
 Description : Lab 8 CPU fetch and decode functions in C
 ============================================================================
 */

/*
 * Lab 8 will perform the following functions:
 *   1. Fetch the code stored in memory
 *   2. Decode the code and prepare for execution
 *   3. Print register file and data memory dump
 *
 * Lab 9 will later perform code execution.
 */

#include "header.h"
#include "lab8header.h"

extern char *regNameTab[N_REG];

/*---------------------------------------------------------------
 * Global PC register.
 * It always points to the current instruction in the code section.
 */
unsigned int PCRegister = 0;

/*---------------------------------------------------------------
 * CPU fetch/decode driver for Lab 8.
 * This function:
 *   1. starts PC at CODESECTION
 *   2. fetches one 32-bit machine code
 *   3. decodes the opcode
 *   4. executes the instruction in Lab 9
 *   5. repeats until machineCode becomes 0
 */
void CPU(unsigned char *mem)
{
    unsigned int machineCode = 0;
    unsigned char opcode = 0;
    unsigned int currentPC = 0;

    PCRegister = CODESECTION;

    do{
        printf("\nPC:%X\n", PCRegister);

        currentPC = PCRegister;
        machineCode = CPU_fetchCode((char *)mem, PCRegister);

        if (machineCode == 0)
            break;

        opcode = CPU_Decode(machineCode);
        printf("Decoded Opcode is: %02X\n", opcode);

        /*
         * Lab 9:
         * Execute the decoded instruction.
         */
        CPU_Execution(opcode, machineCode, (char *)mem);

        /*
         * If the instruction did not change PCRegister
         * (normal sequential instruction), move to next instruction.
         * Branch/jump instructions will update PCRegister themselves.
         */
        if (PCRegister == currentPC)
        {
            PCRegister += 4;
        }

    } while (1);

    printRegisterFiles();
    printDataMemoryDump((char *)mem);
}

/*---------------------------------------------------------------
 * Fetch one 32-bit machine code from memory.
 *
 * Instructions are stored using write_dword(),
 * so direct 32-bit read matches the project design.
 */
unsigned int CPU_fetchCode(char *mem, int codeOffset)
{
    return *((unsigned int *)(mem + codeOffset));
}

/*---------------------------------------------------------------
 * Decode one machine code instruction.
 *
 * Return the real opcode field [31:26].
 *
 * For R-type instructions, this returns 0x00,
 * and CPU_Execution() will check the function field [5:0].
 */
unsigned char CPU_Decode(unsigned int machineCode)
{
    return (unsigned char)((machineCode >> 26) & 0x3F);
}

/*---------------------------------------------------------------
 * Execute one machine code instruction.
 *
 * Instructions supported in this lab:
 *   la, lb, bge, lw, sw, add, addi, j
 */
void CPU_Execution(unsigned char opcode, unsigned int machineCode, char *mem)
{
    unsigned char rs = 0;
    unsigned char rt = 0;
    unsigned char rd = 0;
    unsigned char function = 0;
    short immediate = 0;
    unsigned int address = 0;
    unsigned int memAddr = 0;

    switch (opcode)
    {
        case 0b101111:   /* la */
            /*
             * la rt, immediate
             * Load the immediate address into register rt.
             */
            rt = (machineCode & 0x001F0000) >> 16;
            regFile[rt] = machineCode & 0x0000FFFF;

            if (DEBUG_CODE){
                printf("Code Executed: %08X\n", machineCode);
                printf("la -> %s = 0x%08X\n", regNameTab[rt], regFile[rt]);
                printf("****** PC Register is %08X ******\n", PCRegister);
            }
            break;

        case 0b100000:   /* lb */
            /*
             * lb rt, immediate(rs)
             * Load one signed byte from memory into register rt.
             */
            rs = (machineCode & 0x03E00000) >> 21;
            rt = (machineCode & 0x001F0000) >> 16;
            immediate = (short)(machineCode & 0x0000FFFF);

            memAddr = (unsigned int)(regFile[rs] + immediate);
            regFile[rt] = (signed char)read_byte(mem, memAddr);

            if (DEBUG_CODE){
                printf("Code Executed: %08X\n", machineCode);
                printf("lb -> %s = MEM[0x%08X] = 0x%08X\n",
                       regNameTab[rt], memAddr, regFile[rt]);
                printf("****** PC Register is %08X ******\n", PCRegister);
            }
            break;

        case 0b000111:   /* bge */
            /*
             * bge rs, rt, immediate
             * If regFile[rs] >= regFile[rt], branch to target address.
             *
             * In this project, the parser stores the target address
             * directly in the immediate field.
             */
            rs = (machineCode & 0x03E00000) >> 21;
            rt = (machineCode & 0x001F0000) >> 16;
            immediate = (short)(machineCode & 0x0000FFFF);

            if (regFile[rs] >= regFile[rt])
            {
                PCRegister = (unsigned int)immediate;
            }

            if (DEBUG_CODE){
                printf("Code Executed: %08X\n", machineCode);
                printf("bge -> if %s(%d) >= %s(%d), PC = 0x%08X\n",
                       regNameTab[rs], regFile[rs],
                       regNameTab[rt], regFile[rt],
                       PCRegister);
                printf("****** PC Register is %08X ******\n", PCRegister);
            }
            break;

        case 0b100011:   /* lw */
            /*
             * lw rt, immediate(rs)
             * Load one 32-bit word from memory into register rt.
             */
            rs = (machineCode & 0x03E00000) >> 21;
            rt = (machineCode & 0x001F0000) >> 16;
            immediate = (short)(machineCode & 0x0000FFFF);

            memAddr = (unsigned int)(regFile[rs] + immediate);
            regFile[rt] = (int)read_dword(mem, memAddr);

            if (DEBUG_CODE){
                printf("Code Executed: %08X\n", machineCode);
                printf("lw -> %s = MEM[0x%08X] = 0x%08X\n",
                       regNameTab[rt], memAddr, regFile[rt]);
                printf("****** PC Register is %08X ******\n", PCRegister);
            }
            break;

        case 0b101011:   /* sw */
            /*
             * sw rt, immediate(rs)
             * Store one 32-bit word from register rt into memory.
             */
            rs = (machineCode & 0x03E00000) >> 21;
            rt = (machineCode & 0x001F0000) >> 16;
            immediate = (short)(machineCode & 0x0000FFFF);

            memAddr = (unsigned int)(regFile[rs] + immediate);
            write_dword(mem, memAddr, (unsigned int)regFile[rt]);

            if (DEBUG_CODE){
                printf("Code Executed: %08X\n", machineCode);
                printf("sw -> MEM[0x%08X] = %s = 0x%08X\n",
                       memAddr, regNameTab[rt], regFile[rt]);
                printf("****** PC Register is %08X ******\n", PCRegister);
            }
            break;

        case 0b001000:   /* addi */
            /*
             * addi rt, rs, immediate
             * rt = rs + immediate
             */
            rs = (machineCode & 0x03E00000) >> 21;
            rt = (machineCode & 0x001F0000) >> 16;
            immediate = (short)(machineCode & 0x0000FFFF);

            regFile[rt] = regFile[rs] + immediate;

            if (DEBUG_CODE){
                printf("Code Executed: %08X\n", machineCode);
                printf("addi -> %s = %s + %d = 0x%08X\n",
                       regNameTab[rt], regNameTab[rs], immediate, regFile[rt]);
                printf("****** PC Register is %08X ******\n", PCRegister);
            }
            break;

        case 0b000010:   /* j */
            /*
             * j address
             * Jump to instruction index * 4 because instructions
             * are stored every 4 bytes in memory.
             */
            address = machineCode & 0x03FFFFFF;
            PCRegister = address * 4;

            if (DEBUG_CODE){
                printf("Code Executed: %08X\n", machineCode);
                printf("j -> PC = 0x%08X\n", PCRegister);
                printf("****** PC Register is %08X ******\n", PCRegister);
            }
            break;

        case 0b000000:   /* R-type */
            /*
             * For R-type instructions, use the function field [5:0].
             */
            function = (unsigned char)(machineCode & 0x3F);

            switch (function)
            {
                case 0b100000:   /* add */
                    /*
                     * add rd, rs, rt
                     * rd = rs + rt
                     */
                    rs = (machineCode & 0x03E00000) >> 21;
                    rt = (machineCode & 0x001F0000) >> 16;
                    rd = (machineCode & 0x0000F800) >> 11;

                    regFile[rd] = regFile[rs] + regFile[rt];

                    if (DEBUG_CODE){
                        printf("Code Executed: %08X\n", machineCode);
                        printf("add -> %s = %s + %s = 0x%08X\n",
                               regNameTab[rd], regNameTab[rs],
                               regNameTab[rt], regFile[rd]);
                        printf("****** PC Register is %08X ******\n", PCRegister);
                    }
                    break;

                default:
                    printf("Wrong R-type function! You need to fix this instruction %02X %08X\n",
                           function, machineCode);
                    system("PAUSE");
                    exit(3);
                    break;
            }
            break;

        default:
            printf("Wrong instruction! You need to fix this instruction %02X %08X\n",
                   opcode, machineCode);
            system("PAUSE");
            exit(3);
            break;
    }
}

/*---------------------------------------------------------------
 * Print all 32 registers from regFile[] with names from regNameTab[].
 */
void printRegisterFiles()
{
    int i = 0;

    puts("\n---- Register File ----");
    for (i = 0; i < N_REG; i++)
    {
        printf("%-6s = 0x%08X\n", regNameTab[i], regFile[i]);
    }
}

/*---------------------------------------------------------------
 * Dump the first 256 bytes from the data section.
 */
void printDataMemoryDump(char *mem)
{
    puts("\n---- Data Memory Dump ----");
    memory_dump(mem, DATASECTION, 256);
}
