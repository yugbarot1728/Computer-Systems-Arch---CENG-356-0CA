/*
 ============================================================================
 Name        : lab8header.h
 Author      : Austin Tian
 Revised by  : Yug Barot
 Version     :
 Copyright   : Copyright 2023
 Description : Header file for Lab 8 CPU fetch/decode functions
 ============================================================================
 */

#ifndef LAB8HEADER_H
#define LAB8HEADER_H

/*---------------------------------------------------------------
 * Global PC register declaration.
 * Defined in lab8_9.c, declared here with extern.
 */
extern unsigned int PCRegister;

/*---------------------------------------------------------------
 * Function prototypes for Lab 8 and Lab 9.
 */
unsigned int CPU_fetchCode(char *mem, int codeOffset);
unsigned char CPU_Decode(unsigned int machineCode);
void CPU_Execution(unsigned char opcode, unsigned int machineCode, char *mem);
void printRegisterFiles(void);
void printDataMemoryDump(char *mem);
void CPU(unsigned char *mem);

#endif /* LAB8HEADER_H */
