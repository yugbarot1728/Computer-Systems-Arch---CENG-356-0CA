#ifndef HEADER_H
#define HEADER_H

#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <sys/param.h>
#include <stdbool.h>
#include <ctype.h>

#define MEM_SIZE 1024*1024
#define MIN_DUMP_SIZE 256
#define DUMP_LINE 16

#define N_REG 34
#define MAX_SIZE 2*1024
#define MAX_LABEL 256

#define REG_LO 32
#define REG_HI 33

#define STACK_SEGMENT_BASE (MAX_SIZE - 4)
#define DATA_SEGMENT_BASE 0
#define TEXT_SEGMENT_BASE 0

#define DEBUG_CODE 1
#define Endian LITTLE_ENDIAN

#define WORD_SIZE 4
#define DATASECTION 0x2000
#define CODESECTION 0x0000
#define BUFMAX 128

enum segment {DATA=1, TEXT=2};

typedef struct MIPS_Instruction
{
    char instruction[8];
    int rd;
    int rs;
    int rt;
    int shamt;
    int function;

    union{
        int immediate;
        int address;
    };

    unsigned int machineCode;
} MIPS_Instruction;

typedef struct labelType
{
    char label[20];
    int addr;
    char type;
} labelType;

/* globals: declaration only */
extern MIPS_Instruction Instruction_storage[MAX_SIZE];
extern int regFile[N_REG];
extern char Data_storage[MAX_SIZE];
extern unsigned int totalDataByte;
extern labelType labelTab[MAX_LABEL];

/* parser / memory */
void parse_MIPS(FILE *fp);
void setup_memory(void);
void loadCodeToMem(char *mem);
char *init_memory(void);
void free_memory(char *base_address);
unsigned char rand_generator(void);

void write_byte(const char *base_address, const int offset, const unsigned char byte_data);
void write_dword(const char *base_address, const int offset, const unsigned int dword_data);
unsigned char read_byte(const char *base_address, int offset);
unsigned int read_dword(const char *base_address, int offset);
void memory_dump(const char *base_address, const int offset, unsigned int dumpsize);

#endif
