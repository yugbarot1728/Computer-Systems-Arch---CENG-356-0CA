/*
 ============================================================================
 Name        : memory.c
 Author      : Austin Tian
 Revised by  : Yug Barot
 Version     :
 Copyright   : Copyright 2023
 Description : Memory functions for Lab 6 / Lab 7 / Lab 8 in C, ANSI-C Style
 ============================================================================
 */

#include "header.h"
#include <time.h>

/*
 * This menu is only for Lab 6 style testing.
 * For Lab 7 and Lab 8, memory functions are mainly used by main.c, lab7.c and lab8_9.c.
 */
char *menu =    "\n" \
                " ***********Please select the following options**********************\n" \
                " *    This is the memory operation menu (Lab 6)                     *\n" \
                " ********************************************************************\n" \
                " *    1. Write a double-word (32-bit) to the memory                 *\n"  \
                " ********************************************************************\n" \
                " *    2. Read a byte (8-bit) data from the memory                   *\n" \
                " *    3. Read a double-word (32-bit) data from the memory           *\n" \
                " ********************************************************************\n" \
                " *    4. Generate a memory dump from any memory location            *\n" \
                " ********************************************************************\n" \
                " *    e. To Exit, Type 'e'  or 'E'                                  *\n" \
                " ********************************************************************\n";

/*---------------------------------------------------------------
 * Generate a random number between 0x00 and 0xFF.
 * This was used in earlier labs, but Lab 7/Lab 8 memory is initialized to 0.
 */
unsigned char rand_generator()
{
    return rand() % 256;
}

/*---------------------------------------------------------------
 * Free the allocated memory to avoid memory leak.
 */
void free_memory(char *base_address)
{
    free(base_address);
    return;
}

/*---------------------------------------------------------------
 * Initialize the whole memory space.
 * For Lab 7 and later, all memory locations should be filled with 0.
 */
char *init_memory()
{
    char *mem = malloc(MEM_SIZE);

    if (mem == NULL)
    {
        printf("Memory allocation failed.\n");
        exit(1);
    }

    for (unsigned int i = 0; i < MEM_SIZE; i++)
    {
        mem[i] = 0;
    }

    return mem;
}

/*---------------------------------------------------------------
 * Write one double-word (32-bit) into memory at the given offset.
 * This is how instructions are stored in the code section.
 */
void write_dword(const char *base_address, const int offset, const unsigned int dword_data)
{
    if (offset < 0 || offset > MEM_SIZE - 4)
    {
        printf("Invalid offset. Double-word write out of memory range.\n");
        return;
    }

    *((unsigned int *)(base_address + offset)) = dword_data;

    printf("Data %08Xh is written to address %p\n",
           dword_data, (void *)(base_address + offset));
}

/*---------------------------------------------------------------
 * Read one byte (8-bit) from memory.
 */
unsigned char read_byte(const char *base_address, const int offset)
{
    if (offset < 0 || offset >= MEM_SIZE)
    {
        printf("Invalid offset. Byte read out of memory range.\n");
        return 0;
    }

    unsigned char data = *(unsigned char *)(base_address + offset);

    printf("The BYTE data at address %p is %02Xh\n",
           (void *)(base_address + offset), data);

    return data;
}

/*---------------------------------------------------------------
 * Read one double-word (32-bit) from memory.
 */
unsigned int read_dword(const char *base_address, const int offset)
{
    if (offset < 0 || offset > MEM_SIZE - 4)
    {
        printf("Invalid offset. Double-word read out of memory range.\n");
        return 0;
    }

    unsigned int data = *((unsigned int *)(base_address + offset));

    printf("The DWORD data at address %p is %08Xh\n",
           (void *)(base_address + offset), data);

    return data;
}

/*---------------------------------------------------------------
 * Display a memory dump from the given offset.
 * The dump shows:
 *   1. memory addresses
 *   2. hex bytes
 *   3. ASCII view
 */
void memory_dump(const char *base_address, const int offset, unsigned int dumpsize)
{
    if (offset < 0 || offset >= MEM_SIZE)
    {
        printf("Invalid offset. Dump start is out of memory range.\n");
        return;
    }

    if (dumpsize < MIN_DUMP_SIZE || dumpsize > MEM_SIZE)
        dumpsize = MIN_DUMP_SIZE;

    if ((unsigned int)offset + dumpsize > MEM_SIZE)
        dumpsize = MEM_SIZE - offset;

    const unsigned char *start = (const unsigned char *)(base_address + offset);

    for (unsigned int i = 0; i < dumpsize; i += DUMP_LINE)
    {
        printf("%p: ", (void *)(start + i));

        for (unsigned int j = 0; j < DUMP_LINE; j++)
        {
            if (i + j < dumpsize)
                printf("%02X ", start[i + j]);
            else
                printf("   ");
        }

        printf(" --- ");

        for (unsigned int j = 0; j < DUMP_LINE; j++)
        {
            if (i + j < dumpsize)
            {
                unsigned char c = start[i + j];
                if (c >= 0x20 && c <= 0x7E)
                    printf("%c", c);
                else
                    printf(".");
            }
        }

        printf("\n");
    }

    return;
}

/*---------------------------------------------------------------
 * Lab 6 interactive memory setup/testing function.
 * This function is kept for completeness from the earlier lab.
 */
void setup_memory()
{
    char *mem = init_memory();
    char options = 0;
    unsigned int offset, dumpsize;
    char tempchar;
    unsigned int dword_data;

    do{
        if (options != 0x0a)
        {
            puts(menu);
            printf("\nThe base address of your memory is: %I64Xh (HEX)\n",
                   (long long unsigned int)(mem));
            puts("Please make a selection:");
        }

        options = getchar();

        switch (options)
        {
            case '1':
                puts("Please input your memory's offset address (in HEX):");
                scanf("%x", (unsigned int*)&offset);
                puts("Please input your DOUBLE WORD data to be written (in HEX):");
                scanf("%x", (unsigned int*)&dword_data);
                write_dword(mem, offset, dword_data);
                continue;

            case '2':
                puts("Please input your memory's offset address (in HEX):");
                scanf("%x", &offset);
                read_byte(mem, offset);
                continue;

            case '3':
                puts("Please input your memory's offset address (in HEX):");
                scanf("%x", &offset);
                read_dword(mem, offset);
                continue;

            case '4':
                puts("Please input your memory's offset address (in HEX, should be a multiple of 0x10h):");
                scanf("%x", &offset);
                puts("Please input the size of the memory to be dumped (between 256 and 1M ):");
                scanf("%d", &dumpsize);
                memory_dump(mem, offset, dumpsize);
                continue;

            case 'e':
            case 'E':
                puts("Code finished, press any key to exit");
                free_memory(mem);
                while ((tempchar = getchar()) != '\n' && tempchar != EOF);
                tempchar = getchar();
                return;

            default:
                continue;
        }
    } while (1);
}
