#ifndef PARSER_H
#define PARSER_H

#include "header.h"

/*---------------------------------------------------------------
 * Parser function prototypes
 *--------------------------------------------------------------*/

/* Return register number from register name */
int getRegNum(char *regName);

/* Add a new label into the label list */
int addLabel(char *label, int segType, int offset);

/* Find label offset/address from label table */
int findLabel(char *label);

/* Parse one line of assembly code */
int parseLine(char *line,
              unsigned int *machineCode,
              char *datasection,
              unsigned int *dataSize,
              int *segType,
              int *offset);

/* Convert assembly file into machine code / data section */
int parseASM(char *filename,
             unsigned int *machineCode,
             unsigned int *numberOfInstructions,
             char *datasection,
             unsigned int *numberOfBytes);

#endif
