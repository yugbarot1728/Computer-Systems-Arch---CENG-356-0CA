/*
 ============================================================================
 Name        : lab7.c
 Author      : Austin Tian
 Revised by  : Yug Barot
 Version     :
 Copyright   : Copyright 2023
 Description : Lab 7 code loading functions in C, ANSI-C Style
 ============================================================================
 */

#include "header.h"

/*---------------------------------------------------------------
 * Copy the parsed data section into memory.
 * The data section starts from DATASECTION offset.
 */
void setupDataMemory(char *base_address,
                     unsigned int offset,
                     char *datasection,
                     unsigned int numberOfBytes)
{
    unsigned int i = 0;

    for (i = 0; i < numberOfBytes; i++)
    {
        *(base_address + offset + i) = datasection[i];
    }

    return;
}

/*---------------------------------------------------------------
 * Build an I-type instruction.
 * Format:
 * opcode(6) | rs(5) | rt(5) | immediate(16)
 */
unsigned int buildIInstruction(unsigned char opcode,
                               unsigned char rs,
                               unsigned char rt,
                               int immediate)
{
    unsigned int machineCode = 0;
    unsigned int mask = 0;

    machineCode = immediate & 0x0000FFFF;

    mask = ((unsigned int)(rs & 0x000000FF)) << 21;
    machineCode = machineCode | mask;

    mask = ((unsigned int)(rt & 0x000000FF)) << 16;
    machineCode = machineCode | mask;

    mask = ((unsigned int)(opcode & 0x000000FF)) << 26;
    machineCode = machineCode | mask;

    return machineCode;
}

/*---------------------------------------------------------------
 * Build a J-type instruction.
 * Format:
 * opcode(6) | address/immediate(26)
 */
unsigned int buildJInstruction(unsigned char opcode,
                               int immediate)
{
    unsigned int machineCode = 0;
    unsigned int mask = 0;

    machineCode = immediate & 0x03FFFFFF;

    mask = ((unsigned int)(opcode & 0x000000FF)) << 26;
    machineCode = machineCode | mask;

    return machineCode;
}

/*---------------------------------------------------------------
 * Build an R-type instruction.
 * Format:
 * opcode(6) | rs(5) | rt(5) | rd(5) | shamt(5) | function(6)
 */
unsigned int buildRInstruction(unsigned char opcode,
                               unsigned char rs,
                               unsigned char rt,
                               unsigned char rd,
                               unsigned char shamt,
                               unsigned char function)
{
    unsigned int machineCode = 0;
    unsigned int mask = 0;

    mask = ((unsigned int)(function & 0x000000FF));
    machineCode = machineCode | mask;

    mask = ((unsigned int)(shamt & 0x000000FF)) << 6;
    machineCode = machineCode | mask;

    mask = ((unsigned int)(rd & 0x000000FF)) << 11;
    machineCode = machineCode | mask;

    mask = ((unsigned int)(rt & 0x000000FF)) << 16;
    machineCode = machineCode | mask;

    mask = ((unsigned int)(rs & 0x000000FF)) << 21;
    machineCode = machineCode | mask;

    mask = ((unsigned int)(opcode & 0x000000FF)) << 26;
    machineCode = machineCode | mask;

    return machineCode;
}

/*---------------------------------------------------------------
 * Convert parsed instructions into machine code
 * and store them into memory starting from codeOffset.
 *
 * Instructions supported in this lab:
 * la, lb, bge, lw, sw, add, addi, j
 */
void setupInstructionMemory(char *base_memory_address,
                            int codeOffset,
                            MIPS_Instruction *instructionStorage)
{
    int i = 0;
    unsigned int totalinstruction = 0;
    unsigned char opcode = 0;
    unsigned int machineCode = 0;
    unsigned char function = 0;

    do {
        if (strcmp(instructionStorage[i].instruction, "la") == 0 ){
            opcode = 0b101111;
            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
        }
        else if (strcmp(instructionStorage[i].instruction, "lb") == 0 ){
            opcode = 0b100000;
            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
        }
        else if (strcmp(instructionStorage[i].instruction, "bge") == 0 ){
            opcode = 0b000111;
            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
        }
        else if (strcmp(instructionStorage[i].instruction, "lw") == 0 ){
            opcode = 0b100011;
            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
        }
        else if (strcmp(instructionStorage[i].instruction, "sw") == 0 ){
            opcode = 0b101011;
            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
        }
        else if (strcmp(instructionStorage[i].instruction, "add") == 0 ){
            opcode = 0b000000;
            function = 0b100000;
            machineCode = buildRInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].rd,
                                            0,
                                            function);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
        }
        else if (strcmp(instructionStorage[i].instruction, "addi") == 0 ){
            opcode = 0b001000;
            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
        }
        else if (strcmp(instructionStorage[i].instruction, "j") == 0 ){
            opcode = 0b000010;
            machineCode = buildJInstruction(opcode,
                                            instructionStorage[i].address);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
        }
        else if (strcmp(instructionStorage[i].instruction, "syscall") == 0 ||
                 strcmp(instructionStorage[i].instruction, "END") == 0)
        {
            break;
        }

        i++;
    } while (1);

    totalinstruction = i;
    (void)totalinstruction;
}

/*---------------------------------------------------------------
 * Load both data section and instruction section into memory.
 * Data starts at DATASECTION.
 * Code starts at CODESECTION.
 */
void loadCodeToMem(char *mem)
{
    unsigned int dataSection = DATASECTION;
    unsigned int instructionSection = CODESECTION;

    /* Step 1: copy parsed data section into memory */
    setupDataMemory(mem, dataSection, Data_storage, totalDataByte);

    /* Step 2: convert instructions to machine code and store them in memory */
    setupInstructionMemory(mem, instructionSection, Instruction_storage);

    /* Step 3: display memory dump for checking */
    puts("\n---- Data Section ----\n");
    memory_dump(mem, DATASECTION, 256);

    puts("\n---- Code Section ----\n");
    memory_dump(mem, CODESECTION, 256);
}
