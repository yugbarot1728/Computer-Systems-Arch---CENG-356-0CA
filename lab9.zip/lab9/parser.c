#include "header.h"
#include "parser.h"
#include "MIPS.asm.h"

/*
 * Global definitions
 * These must be defined in ONE .c file only.
 */
 MIPS_Instruction Instruction_storage[MAX_SIZE];
int regFile[N_REG] = {0};
char Data_storage[MAX_SIZE] = {0};
unsigned int totalDataByte = 0;
labelType labelTab[MAX_LABEL];
int n_Label = 0;

char *regNameTab[N_REG] = {
    "$zero", "$at", "$v0", "$v1", "$a0", "$a1", "$a2", "$a3",
    "$t0", "$t1", "$t2", "$t3", "$t4", "$t5", "$t6", "$t7",
    "$s0", "$s1", "$s2", "$s3", "$s4", "$s5", "$s6", "$s7",
    "$t8", "$t9", "$k0", "$k1", "$gp", "$sp", "$fp", "$ra",
    "lo", "hi"
};

/*
 * label table
 * If your original project already has a label struct in header.h,
 * keep that one and remove this block.
 */
typedef struct {
    char labelName[64];
    int segType;
    int offset;
} LABEL_ENTRY;

static LABEL_ENTRY labelTable[MAX_LABEL];

/**
 * lowercase helper
 */
char *strlwr(char *s)
{
    char *p = s;
    while (*p) {
        *p = (char)tolower((unsigned char)*p);
        p++;
    }
    return s;
}

/**
 * Given the register name, return the corresponding register number.
 * If register number is directly given, return the number back.
 *
 * @param regName register name (ex. $t0, $s0, $sp, etc.)
 * @return register number, or -1 if not found
 */
int getRegNum(char *regName)
{
    int i;

    if (regName == NULL) {
        return -1;
    }

    if (regName[0] == '\0') {
        return -1;
    }

    if (regName[1] != '\0' && isdigit((unsigned char)regName[1])) {
        return atoi(regName + 1);
    } else {
        for (i = 0; i < N_REG; i++) {
            if (strcmp(regName, regNameTab[i]) == 0) {
                return i;
            }
        }
    }

    return -1;
}

/**
 * add a new label into the label list
 *
 * @param label   the label name
 * @param segType segment type
 * @param offset  label offset
 * @return 0 if success, -1 if fail
 */
int addLabel(char *label, int segType, int offset)
{
    if (label == NULL) {
        return -1;
    }

    if (n_Label >= MAX_LABEL) {
        printf("Error: label table overflow.\n");
        return -1;
    }

    strncpy(labelTable[n_Label].labelName, label, sizeof(labelTable[n_Label].labelName) - 1);
    labelTable[n_Label].labelName[sizeof(labelTable[n_Label].labelName) - 1] = '\0';
    labelTable[n_Label].segType = segType;
    labelTable[n_Label].offset = offset;

    n_Label++;
    return 0;
}

/**
 * Find the offset address from the label table.
 *
 * @param label label name
 * @return offset if found, -1 if not found
 */
int findLabel(char *label)
{
    int i;

    if (label == NULL) {
        return -1;
    }

    for (i = 0; i < n_Label; i++) {
        if (strcmp(label, labelTable[i].labelName) == 0) {
            return labelTable[i].offset;
        }
    }

    return -1;
}
void parse_MIPS(FILE *fp)
{
    char line[BUFMAX];
    int instrIndex = 0;

    while (fgets(line, sizeof(line), fp) != NULL)
    {
        if (line[0] == '\n' || line[0] == '\0')
            continue;

        if (instrIndex < MAX_SIZE)
        {
            strcpy(Instruction_storage[instrIndex].instruction, "END");
            Instruction_storage[instrIndex].machineCode = 0;
            instrIndex++;
        }
    }

    totalDataByte = 0;
}

void loadCodeToMem(void)
{
    int i;

    /* copy data section into memory-like storage area if needed */
    for (i = 0; i < (int)totalDataByte && i < MAX_SIZE; i++)
    {
        /* placeholder only */
    }

    for (i = 0; i < MAX_SIZE; i++)
    {
        if (Instruction_storage[i].machineCode != 0)
        {
            /* placeholder only */
        }
    }
}
