/*
 ============================================================================
 Name        : main.c
 Author      : Austin Tian
 Revised by  : Yug Barot
 Version     :
 Copyright   : Copyright 2023
 Description : Main driver file for Lab 8 in C
 ============================================================================
 */

/*
 * This main function controls the complete flow of:
 *   Lab 7 -> Parse ASM and load code/data into memory
 *   Lab 8 -> CPU fetch and decode the machine code
 *
 * Flow:
 *   1. Read MIPS assembly file
 *   2. Parse ASM instructions and data
 *   3. Initialize memory
 *   4. Load code + data into memory
 *   5. CPU fetch and decode instructions
 *   6. Free memory
 */

#include "header.h"
#include "lab8header.h"

int main(int argc, char *argv[])
{
    char *mem = NULL;   /* pointer to 1 MB memory space */
    FILE *fp = NULL;    /* file pointer for MIPS.asm */
    int stopChar;       /* used to pause console output */

    /*-----------------------------------------------------------
     * Step 1: Check command line argument
     * Program needs path of MIPS.asm file
     */
    if (argc < 2)
    {
        puts("\nIncorrect number of arguments.");
        puts("Usage: ProgramName.exe MIPSCode.asm\n");
        stopChar = getchar();
        return EXIT_FAILURE;
    }

    /*-----------------------------------------------------------
     * Step 2: Open ASM file
     */
    if ((fp = fopen(argv[1], "r")) == NULL)
    {
        printf("Input file could not be opened.");
        stopChar = getchar();
        return EXIT_FAILURE;
    }

    /*-----------------------------------------------------------
     * Step 3: Parse MIPS assembly file
     * This fills:
     *   Data_storage[]
     *   Instruction_storage[]
     *   labelTab[]
     */
    parse_MIPS(fp);
    fclose(fp);

    /*-----------------------------------------------------------
     * Step 4: Initialize memory
     * For Lab 7 and later, memory should be all zeros
     */
    mem = init_memory();

    /*-----------------------------------------------------------
     * Step 5: Load data section + code section into memory
     *   Data -> DATASECTION
     *   Code -> CODESECTION
     */
    puts("---- Lab 7: Loading Data and Code into Memory ----");
    loadCodeToMem(mem);

    /* pause after Lab 7 dump */
    stopChar = getchar();

    /*-----------------------------------------------------------
     * Step 6: CPU fetch and decode
     * Lab 8 required step
     */
    puts("---- Lab 8: CPU Fetch and Decode Starts ----");
    CPU((unsigned char *)mem);

    /* pause after Lab 8 output */
    stopChar = getchar();

    /*-----------------------------------------------------------
     * Step 7: Free allocated memory
     */
    free_memory(mem);

    return 0;
}
